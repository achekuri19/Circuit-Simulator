import math, copy
import numpy as np
from cmu_112_graphics import *
from termproject import *
from tkinter import *
import random
import decimal



#from http://www.cs.cmu.edu/~112/index.html
def roundHalfUp(d):
    # Round to nearest with ties going away from zero.
    rounding = decimal.ROUND_HALF_UP
    # See other rounding options here:
    # https://docs.python.org/3/library/decimal.html#rounding-modes
    return int(decimal.Decimal(d).to_integral_value(rounding=rounding))

#Graphics app from http://www.cs.cmu.edu/~112/notes/hw9.html
#CMU 112 Graphics (not made by me)
def appStarted(app):
    app.circuit  = Circuit()
    app.compToAdd = 0
    app.pressedNode = None
    app.releasedNode = None
    app.gridW = 35
    app.mouseX = app.width/2
    app.mouseY = app.height/2



def keyPressed(app, event):
    if(event.key == 'v'):
        app.compToAdd = 0
    elif(event.key == 'w'):
        app.compToAdd = 1
    elif(event.key == 'r'):
        app.compToAdd = 2
    elif(event.key == 'g'):
        app.compToAdd = 3
    elif(event.key == 'Space'):
        app.compToAdd = None

def mousePressed(app,event):
    app.pressedNode = getNodeFromCoord(app,event.x,event.y)
    if(app.compToAdd == 3):
        if(app.pressedNode in app.circuit.nodes):
            app.circuit.addGround(app.pressedNode)
            app.pressedNode = None

def CircuitContains(app,node1,node2):
    for comp in app.circuit.comps:
        if(comp.nodeSet == {node1,node2}):
            return True
    return False

def mouseReleased(app,event):
    app.releasedNode = getNodeFromCoord(app,event.x,event.y)
    if(app.pressedNode != app.releasedNode and
       not CircuitContains(app,app.pressedNode,app.releasedNode)):
        if(app.compToAdd == 0):
            app.circuit.addComp(DCVoltage(app.releasedNode,app.pressedNode,5))
        elif(app.compToAdd == 1):
            app.circuit.addComp(Resistor(app.pressedNode,app.releasedNode))
        elif(app.compToAdd == 2):
            app.circuit.addComp(Resistor(app.pressedNode,app.releasedNode,5))
        trySolve(app)
            
    app.pressedNode = None
    app.releasedNode = None

def trySolve(app):
    app.circuit.reduceCircuit()
    for comp in app.circuit.reducedComps:
        nodeSet = app.circuit.getCompNodes(comp)
        app.circuit.makeNodeDict(nodeSet)
        app.circuit.solveCircuit(comp)
        
        a = np.array(app.circuit.eqList)
        b = np.array(app.circuit.RHSList)
        try:
            mat = np.linalg.solve(a, b)
            for node in app.circuit.nodes:
                voltage = mat[app.circuit.nodeDict[node]]
                node.voltage = voltage
        except:
            print('No solution')
                
            
        

def getNodeFromCoord(app,x,y):
    nodeX = roundHalfUp(x/app.gridW)
    nodeY = roundHalfUp(y/app.gridW)
    return Node(nodeX,nodeY)

def mouseMoved(app,event):
    app.mouseX = event.x
    app.mouseY = event.y

def mouseDragged(app,event):
    app.mouseX = event.x
    app.mouseY = event.y
    
    


def timerFired(app):
    pass
        

def drawWire(app,canvas,resistor):
    node1,node2 = tuple(resistor.nodeSet)
    canvas.create_line(app.gridW*node1.x,app.gridW*node1.y,
                       app.gridW*node2.x,app.gridW*node2.y)

def distance(x1,y1,x2,y2):
    return ((x1-x2)**2 + (y2-y1)**2)**0.5

def drawResistor(app,canvas,resistor):
    node1,node2 = tuple(resistor.nodeSet)
    x1,y1 = app.gridW*node1.x,app.gridW*node1.y
    x2,y2 = app.gridW*node2.x,app.gridW*node2.y
    dist = distance(x1,y1,x2,y2)
    if(dist >= app.gridW*2):
        dX=(x1-x2)*app.gridW/(dist)
        dY=(y1-y2)*app.gridW/(dist)
        midX = (x1+x2)/2
        midY = (y1+y2)/2
        canvas.create_line(midX-dX,midY-dY,x2,y2)
        canvas.create_line(midX+dX,midY+dY,x1,y1)
        drawSquiggly(app,canvas,midX-dX,midY-dY,midX+dX,midY+dY)
    else:
        drawSquiggly(app,canvas,x1,y1,x2,y2)

def drawSquiggly(app,canvas,x1,y1,x2,y2):
    d = distance(x1,y1,x2,y2)
    xInc = (x2-x1)/10
    yInc = (y2-y1)/10
    a = (app.gridW/2)*(y2-y1)/d
    b = (app.gridW/2)*(x2-x1)/d


    canvas.create_line(x1,y1,x1+xInc+a,y1+yInc-b)
    canvas.create_line(x1+xInc+a,y1+yInc-b,x1+3*xInc-a,y1+3*yInc+b)
    canvas.create_line(x1+3*xInc-a,y1+3*yInc+b,x1+5*xInc+a,y1+5*yInc-b)
    canvas.create_line(x1+5*xInc+a,y1+5*yInc-b,x1+7*xInc-a,y1+7*yInc+b)
    canvas.create_line(x1+7*xInc-a,y1+7*yInc+b,x1+9*xInc+a,y1+9*yInc-b)
    canvas.create_line(x1+9*xInc+a,y1+9*yInc-b,x2,y2)

def drawDCVoltage(app,canvas,batt):
    node1,node2 = tuple(batt.nodeSet)
    if(node1 == batt.highNode):
        x1,y1 = app.gridW*node1.x,app.gridW*node1.y
        x2,y2 = app.gridW*node2.x,app.gridW*node2.y
    else:
        x1,y1 = app.gridW*node2.x,app.gridW*node2.y
        x2,y2 = app.gridW*node1.x,app.gridW*node1.y

    dist = distance(x1,y1,x2,y2)

    dX=(x1-x2)*app.gridW/(3*dist)
    dY=(y1-y2)*app.gridW/(3*dist)
    midX = (x1+x2)/2
    midY = (y1+y2)/2
    canvas.create_line(midX-dX,midY-dY,x2,y2)
    canvas.create_line(midX+dX,midY+dY,x1,y1)

    x3,y3 = midX+dX,midY+dY
    x4,y4 = midX-dX,midY-dY

    d = distance(x3,y3,x4,y4)

    a = (app.gridW/2)*(y4-y3)/d
    b = (app.gridW/2)*(x4-x3)/d

    canvas.create_line(x3+1.5*a,y3-1.5*b,x3-1.5*a,y3+1.5*b)

    canvas.create_line(x4+a,y4-b,x4-a,y4+b)
    
def drawGround(app,canvas,node):
    x,y = node.x*app.gridW,node.y*app.gridW
    canvas.create_line(x,y,x,y+app.gridW/6)
    canvas.create_line(x-app.gridW/3,y+app.gridW/6,
                       x+app.gridW/3,y+app.gridW/6)
    canvas.create_line(x-app.gridW/6,y+app.gridW/3,
                       x+app.gridW/6,y+app.gridW/3)
    canvas.create_line(x-app.gridW/12,y+app.gridW/2,
                       x+app.gridW/12,y+app.gridW/2)
    
def printNodeVoltage(app,canvas,node):
    canvas.create_text(app.width/2,app.height-20,text=f'Voltage: {node.voltage}')

def redrawAll(app, canvas):
    for comp in app.circuit.comps:
        if(isinstance(comp,Resistor) and comp.resistance == 0):
            drawWire(app,canvas,comp)
        elif(isinstance(comp,Resistor) and comp.resistance != 0):
            drawResistor(app,canvas,comp)
        elif(isinstance(comp,DCVoltage)):
            drawDCVoltage(app,canvas,comp)
    for node in app.circuit.nodes:
        if(node.grounded):
            drawGround(app,canvas,node)
    if(app.pressedNode != None):
        mouseNode = getNodeFromCoord(app,app.mouseX,app.mouseY)
        if(mouseNode != app.pressedNode):
            if(app.compToAdd == 1):
                drawWire(app,canvas,Resistor(app.pressedNode,mouseNode))
            elif(app.compToAdd == 2):
                drawResistor(app,canvas,Resistor(app.pressedNode,mouseNode))
            elif(app.compToAdd == 0):
                drawDCVoltage(app,canvas,DCVoltage(mouseNode,app.pressedNode))

    mouseNode = getNodeFromCoord(app,app.mouseX,app.mouseY)
    for node in app.circuit.nodes:
        if(mouseNode == node):
            printNodeVoltage(app,canvas,node)

                
            
        

runApp(width=800,height=800)
