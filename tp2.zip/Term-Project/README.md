# Term-Project

This is the TP2 version of my term project. Right now, all it does is create circuits and simulate them.
The program to run if you want the GUI is 'driver.py'. This opens a circuit simulator. To add components,
you click and drag across the screen. 

Press 'v' if you want to add a voltage source, 'g' if you want to add ground, 'w' if you want to add a wire
and 'r' if you want to add a resistor. Right now, if you hover over the nodes (intersection of two components)
you'll see a voltage at the bottom of the screen. This is the calculated voltage of the node.

All calculations/circuit solving are done in termproject.py

The graphics framework is CMU 112's animation framework. 
