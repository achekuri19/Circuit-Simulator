################################################################
#Official Term Project of Akshay Chekuri
#andrewid: achekuri
################################################################

#################################################
# Helper functions
#################################################

#from http://www.cs.cmu.edu/~112/index.html

def almostEqual(d1, d2, epsilon=10**-7):
    # note: use math.isclose() outside 15-112 with Python version 3.5 or later
    return (abs(d2 - d1) < epsilon)

import decimal

#from http://www.cs.cmu.edu/~112/index.html

def roundHalfUp(d):
    # Round to nearest with ties going away from zero.
    rounding = decimal.ROUND_HALF_UP
    # See other rounding options here:
    # https://docs.python.org/3/library/decimal.html#rounding-modes
    return int(decimal.Decimal(d).to_integral_value(rounding=rounding))
import numpy as np
import copy

class ATMega88p(object):
    def __init__(self,code):
        self.code = code
        
        

class Node(object): 
    def __init__(self,x,y,voltage=0):
        self.voltage = voltage
        self.x = x
        self.y = y
        self.grounded = False
    def __repr__(self):
        return f'Node {self.x},{self.y} {self.grounded}'
    def __hash__(self):
        return hash((self.x,self.y))
    def __eq__(self,other):
        return isinstance(other,Node) and hash(self) == hash(other)

class Component(object):
    def __init__(self,node1,node2):
        self.nodeSet = {node1,node2}
    def orgNodeSetList(self):
        node1,node2 = tuple(self.nodeSet)
        if(hash(node1) <= hash(node2)):
            return [node1,node2]
        else:
            return [node2,node1]

        

class Resistor(Component):
    def __init__(self,node1,node2,resistance=0):
        super().__init__(node1,node2)
        self.resistance = resistance
    def __hash__(self):
        return hash(tuple(self.orgNodeSetList()))
    def __eq__(self,other):
        return isinstance(other,Resistor) and self.orgNodeSetList() == other.orgNodeSetList()
    def __repr__(self):
        return f'Resistor @ {self.nodeSet}'
        

class DCVoltage(Component):
    def __init__(self,node1,node2,voltage=0):
        super().__init__(node1,node2)
        self.highNode = node1
        self.voltage = voltage
    def __hash__(self):
        return hash((tuple(self.orgNodeSetList()),self.voltage))
    def __eq__(self,other):
        return isinstance(other,DCVoltage) and hash(self) == hash(other)
    def __repr__(self):
        return f'DCVoltage @ {self.nodeSet}'

class ParallelCombo(Component):
    def __init__(self,node1,node2,parallelSet):
        super().__init__(node1,node2)
        self.parallelSet = parallelSet
    def __hash__(self):
        return hash(tuple(self.orgParSetList()))
    def __eq__(self,other):
        return isinstance(other,ParallelCombo) and hash(self) == hash(other)
    def __repr__(self):
        return f'Parallel Combo @ {self.nodeSet} with components {self.parallelSet}'
        #return f'Parallel Combo @ {self.nodeSet}'
    def orgParSetList(self):
        hashList = []
        for comp in self.parallelSet:
            hashList.append(hash(comp))
        hashList.sort()
        return hashList

class PerfectLoop(Component):
    def __init__(self,node1,node2,loopSet):
        super().__init__(node1,node2)
        self.loopSet = loopSet
    def __hash__(self):
        return hash(tuple(self.orgLoopSetList()))
    def __eq__(self,other):
        return isinstance(other,PerfectLoop) and hash(self) == hash(other)
    def __repr__(self):
        return f'Perfect Loop with components {self.loopSet}'
        #return f'Parallel Combo @ {self.nodeSet}'
    def orgLoopSetList(self):
        hashList = []
        for comp in self.loopSet:
            hashList.append(hash(comp))
        hashList.sort()
        return hashList

class SeriesCombo(Component):
    def __init__(self,node1,node2,seriesSet):
        super().__init__(node1,node2)
        self.seriesSet = seriesSet
    def __hash__(self):
        return hash(tuple(self.orgSerSetList()))
    def __eq__(self,other):
        return isinstance(other,SeriesCombo) and hash(self) == hash(other)
    def __repr__(self):
        return f'Series combo @ {self.nodeSet} with components {self.seriesSet}'
        #return f'Series Combo @ {self.nodeSet}'
    def orgSerSetList(self):
        hashList = []
        for comp in self.seriesSet:
            hashList.append(hash(comp))
        hashList.sort()
        return hashList

class Circuit(object):
    def __init__(self):
        self.nodes = dict()
        self.comps = set()
        self.reducedNodes = dict()
        self.reducedComps = set()
        self.eqList = []
        self.RHSList = []
        self.nodeDict = dict()

    def addComp(self,comp):
        self.comps.add(comp)
        
        node1, node2 = tuple(comp.nodeSet)
        if(node1 in self.nodes):
            self.nodes[node1].add(comp)
        else:
            self.nodes[node1] = {comp}
        if(node2 in self.nodes):
            self.nodes[node2].add(comp)
        else:
            self.nodes[node2] = {comp}
        self.reducedNodes = copy.deepcopy(self.nodes)
        self.reducedComps = copy.deepcopy(self.comps)
        self.eqList = []
        self.RHSList = []
        #self.makeNodeDict()
        
    def addGround(self,sampleNode):
        for node in self.nodes:
            if(sampleNode == node):
                node.grounded = True
                for comp in self.nodes[node]:
                    self.comps.remove(comp)
                    node1,node2 = tuple(comp.nodeSet)
                    if(node1 == node):
                        comp.nodeSet = {node,node2}
                    else:
                        comp.nodeSet = {node,node1}
                    self.comps.add(comp)
        self.eqList = []
        self.RHSList = []
            

    def makeNodeDict(self,nodeSet):
        nodeDict = dict()
        i = 0
        for node in nodeSet:
            nodeDict[node] = i
            i += 1
        self.nodeDict = nodeDict
        
            

    def addComboComp(self,comp):
        self.reducedComps.add(comp)
        node1, node2 = tuple(comp.nodeSet)
        if(node1 in self.reducedNodes):
            self.reducedNodes[node1].add(comp)
        else:
            self.reducedNodes[node1] = {comp}
        if(node2 in self.reducedNodes):
            self.reducedNodes[node2].add(comp)
        else:
            self.reducedNodes[node2] = {comp}

    def removeComboComp(self,comp):
        #bugs with hash function, this fixes it
        node1, node2 = tuple(comp.nodeSet)
        self.reducedComps.remove(comp)
        self.reducedNodes[node1].remove(comp)
        self.reducedNodes[node2].remove(comp)
        if(self.reducedNodes[node1] == set()):
            del self.reducedNodes[node1]
        if(self.reducedNodes[node2] == set()):
            del self.reducedNodes[node2]

    def getSeries(self):
        branchList = []
        for node in self.reducedNodes:
            compList = copy.deepcopy(self.reducedNodes[node])
            if(len(compList) == 2):
                added = False
                for i in range(len(branchList)):
                    branch = branchList[i]
                    for comp in compList:
                        if comp in branch:
                            newBranch = branch|compList
                            added = True
                            if(self.branchValid(newBranch)):
                                branchList[i] = newBranch
                if not added:
                    branchList.append(compList)
        return branchList

    def branchValid(self,branch):
        for comp in branch:
            node1,node2 = tuple(comp.nodeSet)
            compList1 = copy.deepcopy(self.reducedNodes[node1])
            compList2 = copy.deepcopy(self.reducedNodes[node2])
            if(len(compList1) > 2 or len(compList2) > 2):
                return False
        return True
            
    def getBranchStartEnd(self,branch):
        nodeSet = set()
        for comp in branch:
            node1,node2 = tuple(comp.nodeSet)
            if(node1 in nodeSet):
                nodeSet.remove(node1)
            else:
                nodeSet.add(node1)
            if(node2 in nodeSet):
                nodeSet.remove(node2)
            else:
                nodeSet.add(node2)
        return nodeSet
    
    def reduceFromBranchList(self,branchList):
        for branch in branchList:
            nodeSet = self.getBranchStartEnd(branch)
            for comp in branch:
                self.removeComboComp(comp)
            if(len(nodeSet) == 2):
                node1,node2 = tuple(nodeSet)
                self.addComboComp(SeriesCombo(node1,node2,branch))
            else:
                firstComp = list(branch)[0]
                node1,node2 = tuple(firstComp.nodeSet)
                self.addComboComp(PerfectLoop(node1,node2,branch))

    def getParallel(self):
        parallelList = []
        reducedComps = copy.deepcopy(self.reducedComps)
        for comp in reducedComps:
            parallelSet = set()
            for comp2 in reducedComps:
                if comp2.nodeSet == comp.nodeSet:
                    parallelSet.add(comp2)
            if(len(parallelSet)>1 and parallelSet not in parallelList):
                parallelList.append(parallelSet)
        return parallelList

    def reduceFromParallelList(self,parallelList):        
        for parallelSet in parallelList:
            nodeSet = set()
            for comp in parallelSet:
                nodeSet = comp.nodeSet
                self.removeComboComp(comp)
            node1,node2 = tuple(nodeSet)
            self.addComboComp(ParallelCombo(node1,node2,parallelSet))
    
    def reduceCircuit(self):
        branchList = [1]
        parallel = [1]

        while(branchList != [] or parallel != []):
            branchList = self.getSeries()
            self.reduceFromBranchList(branchList)
                
            parallel = self.getParallel()
            self.reduceFromParallelList(parallel)
            
        
        
    def removeRepeats(self):
        newList = []
        newRHS = []
        for i in range(len(self.eqList)):
            exp = self.eqList[i]
            if(not self.containsExp(newList,exp)):
                newList.append(exp)
                newRHS.append(self.RHSList[i])
        self.eqList = newList
        self.RHSList = newRHS

    def containsExp(self,L,exp):
        for exp2 in L:
            if(self.expEqual(exp,exp2)):
                return True
        return False

    def expEqual(self,exp1,exp2):
        for i in range(len(exp1)):
            for j in range(i+1,len(exp1)):
                if(exp1[i] != 0 and exp2[i] != 0 and exp1[j] != 0 and exp2[j] != 0):
                    if(not almostEqual(exp1[i]/exp2[i],exp1[j]/exp2[j])):
                        return False
        for i in range(len(exp1)):
            if((exp1[i] == 0 and exp2[i] != 0) or (exp1[i] != 0 and exp2[i] == 0)):
                return False
        return True
    
    def printComp(self,comp,depth=0):
        dStr = '    '
        if(isinstance(comp,DCVoltage) or
           isinstance(comp,Resistor)):
            print(dStr*depth + f'{comp}')
        elif(isinstance(comp,SeriesCombo)):
            print(dStr*depth + f'Series combo @{comp.nodeSet}')
            for subComp in comp.seriesSet:
                self.printComp(subComp,depth+1)
        elif(isinstance(comp,ParallelCombo)):
            print(dStr*depth + f'Parallel combo @{comp.nodeSet}')
            for subComp in comp.parallelSet:
                self.printComp(subComp,depth+1)
        elif(isinstance(comp,PerfectLoop)):
            print(dStr*depth+f'Perfect loop w/components:')
            for subComp in comp.loopSet:
                self.printComp(subComp, depth+1)

    def solveCircuit(self,comp):
        if(isinstance(comp,PerfectLoop)):
            self.solvePerfectLoop(comp)
        elif(isinstance(comp,ParallelCombo)):
            parallelList = list(comp.parallelSet)
            if(len(parallelList)==2):
                node1,node2 = tuple(parallelList[0].nodeSet)
                self.solveCircuit(PerfectLoop(node1,node2,{parallelList[0],parallelList[1]}))
            else:
                node1,node2 = tuple(parallelList[0].nodeSet)
                parallelComp = ParallelCombo(node1,node2,set(parallelList[1:]))
                pfLoop = PerfectLoop(node1,node2,{parallelList[0],parallelComp})
                self.solveCircuit(pfLoop)

    def solvePerfectLoop(self,comp):
        node1,node2 = comp.nodeSet
        self.createEq(comp,node1)
        grounded = False
        self.removeRepeats()
        for node in self.nodes:
            if(node.grounded):
                grounded = True
                exp = [0]*len(self.nodeDict)
                exp[self.nodeDict[node]] = 1
                self.eqList.append(exp)
                self.RHSList.append(0)
        if(not grounded):
            exp = [0]*len(self.nodeDict)
            exp[self.nodeDict[node1]] = 1
            self.eqList.append(exp)
            self.RHSList.append(0)

    def createEq(self,comp,startNode):
        if(isinstance(comp,DCVoltage)):
            return self.createDCVEq(comp)
        elif(isinstance(comp,Resistor)):
            if(comp.resistance == 0):
                return self.createWireEq(comp)
            else:
                return self.createResistorExp(comp,startNode)
        elif(isinstance(comp,SeriesCombo)):
            return self.createSeriesEqs(comp,startNode)
        elif(isinstance(comp,ParallelCombo)):
            return self.createParallelExp(comp,startNode)
        elif(isinstance(comp,PerfectLoop)):
            self.createLoopEqs(comp)

    def isGrounded(self,node):
        for node2 in self.nodes:
            if(node2 == node and node2.grounded):
                return True

    def getLoopCompOrder(self,nodeSet1,nodeSet2,nodeOrder):
        nodeList = []
        for i in range(len(nodeOrder)-1):
            if(nodeSet1 == set(nodeOrder[i:i+2]) or
               nodeSet2 == set(nodeOrder[i:i+2])):
                nodeList.append(i)
                nodeList.append(i+1)
        return nodeList
            

    def containsGroundsBetweenLoopComps(self,comp1,comp2,nodeOrder):

        nodeList = self.getLoopCompOrder(comp1.nodeSet,comp2.nodeSet,nodeOrder)
        count = 0
        for i in range(nodeList[1],nodeList[2]+1):
            if(self.isGrounded(nodeOrder[i])):
                count += 1
                break
        j = nodeList[3]
        
        for i in range(len(nodeOrder)-nodeList[3]+nodeList[0]+1):
            if(self.isGrounded(nodeOrder[j])):
                count += 1
                break
            j = (j+1)%(len(nodeOrder))
        
        return count == 2
    
    def createLoopEqs(self,comp):
        loopCopy = list(copy.deepcopy(comp.loopSet))

        if(len(comp.loopSet)==2):
            node1,node2 = tuple(loopCopy[0].nodeSet)
            exp1 = self.createEq(loopCopy[0],node1)
            exp2 = self.createEq(loopCopy[1],node2)
            if(exp1 != None and exp2 != None):
                for i in range(len(exp1)):
                    exp1[i] = exp1[i] - exp2[i]
                self.eqList.append(exp1)
                self.RHSList.append(0)
        
        nodeOrderL = self.getLoopOrder(comp)
        edgeComp = None
        
        for subComp in comp.loopSet:
            if(nodeOrderL[-2] in subComp.nodeSet and
               nodeOrderL[-1] in subComp.nodeSet):
                edgeComp = subComp
                loopCopy.remove(subComp)
                break

        edgeExp = self.createEq(edgeComp,nodeOrderL[-2])
        nodeOrderL.pop(-1)
        
        if(edgeExp != None):
            for i in range(len(loopCopy)):
                subComp = loopCopy[i]
                startNode = self.getStartNodeFromOrder(nodeOrderL,subComp)
                exp = self.createEq(subComp,startNode)
                if(exp != None):
                    for i in range(len(edgeExp)):
                        edgeExp[i] = edgeExp[i] - exp[i]
                    self.eqList.append(edgeExp)
                    self.RHSList.append(0)
                    
        for i in range(len(loopCopy)):
            subComp1 = loopCopy[i]
            for j in range(i+1,len(loopCopy)):
                subComp2 = loopCopy[j]
                startNode1 = self.getStartNodeFromOrder(nodeOrderL,subComp1)
                startNode2 = self.getStartNodeFromOrder(nodeOrderL,subComp2)
                exp1 = self.createEq(subComp1,startNode1)
                exp2 = self.createEq(subComp2,startNode2)
                if(exp1 != None and exp2 != None):
                    for i in range(len(exp1)):
                        exp1[i] = exp1[i]-exp2[i]
                    self.eqList.append(exp1)
                    self.RHSList.append(0)

    def getLoopOrder(self,comp):
        loopList = list(copy.deepcopy(comp.loopSet))
        node1,node2 = tuple(loopList[0].nodeSet)
        seriesOrder = [node1,node2]
        loopList.pop(0)
        i = 0
        while(len(loopList) != 0):
            subComp = loopList[i]
            if seriesOrder[-1] in subComp.nodeSet:
                node1,node2 = tuple(subComp.nodeSet)
                if(seriesOrder[-1] == node1):
                    seriesOrder.append(node2)
                else:
                    seriesOrder.append(node1)
                loopList.remove(subComp)
                if(len(loopList)!=0):
                    i = i%len(loopList)
            else:
                if(len(loopList)!=0):
                    i = (i+1)%len(loopList)
        return seriesOrder
                
    def createParallelExp(self,comp,startNode):
        hasInvalid = False
        parallelExp = [0]*len(self.nodeDict)
        for subComp in comp.parallelSet:
            exp = self.createEq(subComp,startNode)
            if(exp != None):
                for i in range(len(parallelExp)):
                    parallelExp[i] += exp[i]
            else:
                hasInvalid = True
        if hasInvalid:
            return None
        else:
            return parallelExp

    def containsGroundBetweenComps(self,comp1,comp2,nodeOrder):
        node1,node2 = tuple(comp1.nodeSet)
        node3,node4 = tuple(comp2.nodeSet)

        if(nodeOrder.index(node1) <= nodeOrder.index(node3) and
           nodeOrder.index(node2) <= nodeOrder.index(node3)):
            startIndex = max(nodeOrder.index(node1),nodeOrder.index(node2))
            endIndex = min(nodeOrder.index(node3), nodeOrder.index(node4))
            
        else:
            startIndex = max(nodeOrder.index(node3),nodeOrder.index(node4))
            endIndex = min(nodeOrder.index(node1), nodeOrder.index(node2))
        for i in range(startIndex,endIndex+1):
            if self.isGrounded(nodeOrder[i]):
                return True
        return False
            
    
    def createSeriesEqs(self,comp,startNode):
        current = None
        node1,node2 = tuple(comp.nodeSet)
        nodeOrderL = self.getSeriesOrder(comp,startNode)
        compList = list(comp.seriesSet)
        for i in range(len(compList)):
            subComp1 = compList[i]
            for j in range(i+1,len(compList)):
                subComp2 = compList[j]
                startNode1 = self.getStartNodeFromOrder(nodeOrderL,subComp1)
                startNode2 = self.getStartNodeFromOrder(nodeOrderL,subComp2)
                exp1 = self.createEq(subComp1,startNode1)
                exp2 = self.createEq(subComp2,startNode2)
                if(exp1 != None and exp2 != None):
                    current = exp1
                    for i in range(len(exp1)):
                        exp1[i] = exp1[i]-exp2[i]
                    self.eqList.append(exp1)
                    self.RHSList.append(0)
                elif(exp1 != None):
                    current = exp1
                elif(exp2 != None):
                    current = exp2
        return current       

    def getStartNodeFromOrder(self,nodeOrder,comp):
        node1,node2 = tuple(comp.nodeSet)
        if(nodeOrder.index(node1) < nodeOrder.index(node2)):
            return node1
        else:
            return node2

    def getCompNodes(self,comp):
        nodeSet = set()
        if(isinstance(comp,DCVoltage)):
            return comp.nodeSet
        elif(isinstance(comp,Resistor)):
            return comp.nodeSet
        elif(isinstance(comp,SeriesCombo)):
            for subComp in comp.seriesSet:
                nodeSet = nodeSet|self.getCompNodes(subComp)
            return nodeSet
        elif(isinstance(comp,ParallelCombo)):
            for subComp in comp.parallelSet:
                nodeSet = nodeSet|self.getCompNodes(subComp)
            return nodeSet
        elif(isinstance(comp,PerfectLoop)):
            for subComp in comp.loopSet:
                nodeSet = nodeSet|self.getCompNodes(subComp)
            return nodeSet


    def createDCVEq(self,comp):
        coeffList = [0]*len(self.nodeDict)
        for node in comp.nodeSet:
            if node == comp.highNode:
                coeffList[self.nodeDict[node]] = 1
            else:
                coeffList[self.nodeDict[node]] = -1
        self.eqList.append(coeffList)
        self.RHSList.append(comp.voltage)
        return None
         
    def createWireEq(self, comp):
        node1,node2=tuple(comp.nodeSet)
        coeffList = [0]*len(self.nodeDict)
        coeffList[self.nodeDict[node1]] = 1
        coeffList[self.nodeDict[node2]] = -1
        self.eqList.append(coeffList)
        self.RHSList.append(0)
        return None

    def createResistorExp(self,comp,startNode):
        node1,node2=tuple(comp.nodeSet)
        coeffList = [0]*len(self.nodeDict)
        if(node1 == startNode):
            coeffList[self.nodeDict[node1]] = 1/comp.resistance
            coeffList[self.nodeDict[node2]] = -1/comp.resistance
            return coeffList
        else:
            coeffList[self.nodeDict[node2]] = 1/comp.resistance
            coeffList[self.nodeDict[node1]] = -1/comp.resistance
            return coeffList

    def getSeriesOrder(self,comp,startNode):
        serList = list(copy.deepcopy(comp.seriesSet))
        seriesOrder = [startNode]
        i = 0
        while(len(serList) != 0):
            subComp = serList[i]
            if seriesOrder[-1] in subComp.nodeSet:
                node1,node2 = tuple(subComp.nodeSet)
                if(seriesOrder[-1] == node1):
                    seriesOrder.append(node2)
                else:
                    seriesOrder.append(node1)
                serList.remove(subComp)
                if(len(serList)!=0):
                    i = i%len(serList)
            else:
                if(len(serList)!=0):
                    i = (i+1)%len(serList)
        return seriesOrder
                    
                



            

def testBranches():
    
    circ = Circuit()
    node1 = Node(0,0)
    node2 = Node(0,1)
    node3 = Node(1,1)
    node4 = Node(2,0)
    node5 = Node(2,2)
    node6 = Node(3,1)
    node7 = Node(4,0)
    #node8 = Node(10,10)
    #node9 = Node(7,7)
    
    batt = DCVoltage(node1,node7,5)
    res1 = Resistor(node1,node3,1)
    res2 = Resistor(node3,node4,1)
    res3 = Resistor(node4,node7,1)
    res4 = Resistor(node3,node5,1)
    res5 = Resistor(node5,node7,1)
    res6 = Resistor(node5,node6,1)
    res7 = Resistor(node6,node7,1)
    #res8 = Resistor(node8,node9)
    
    circ.addComp(batt)
    circ.addComp(res1)
    circ.addComp(res2)
    circ.addComp(res3)
    circ.addComp(res4)
    circ.addComp(res5)
    circ.addComp(res6)
    circ.addComp(res7)
    #circ.addComp(res8)
    #circ.addGround(node4)
    circ.addGround(node7)
    

    circ.reduceCircuit()

    for comp in circ.reducedComps:
        circ.printComp(comp)
        print()
        nodeSet = circ.getCompNodes(comp)
        circ.makeNodeDict(nodeSet)
        circ.solveCircuit(comp)
        for node in circ.nodeDict:
            print(node)
        a = np.array(circ.eqList)
        b= np.array(circ.RHSList)
        for i in range(len(circ.RHSList)):
            print(f'{circ.eqList[i]}     {circ.RHSList[i]}')
        
        mat = np.linalg.solve(a, b)

        for num in mat:
            print(float(num))
        

#testBranches()
        

