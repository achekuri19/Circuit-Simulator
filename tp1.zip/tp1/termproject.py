################################################################
#Official Term Project of Akshay Chekuri
#andrewid: achekuri
#
#README:
#This is the TP1 version. So far, I have created the algorithm
#that determines which components are in parallel and in series
#with each other, and then groups them in that way. This will
#allow me to easily generate instructions on how to construct
#it on a circuit board and also "solve" the circuit for all
#voltages
################################################################

import copy
class Node(object):
    def __init__(self,x,y,voltage=0):
        self.voltage = voltage
        self.x = x
        self.y = y
        self.grounded = False
    def __repr__(self):
        return f'Node {self.x},{self.y}'
    def __hash__(self):
        return hash((self.x,self.y))
    def __eq__(self,other):
        return isinstance(other,Node) and hash(self) == hash(other)

class Component(object):
    def __init__(self,node1,node2):
        self.nodeSet = {node1,node2}

        

class Resistor(Component):
    def __init__(self,node1,node2,resistance=0):
        super().__init__(node1,node2)
        self.resistance = resistance
    def __hash__(self):
        return hash(tuple(self.nodeSet))
    def __eq__(self,other):
        return isinstance(other,Resistor) and self.nodeSet == other.nodeSet
    def __repr__(self):
        return f'Resistor @ {self.nodeSet}'
        

class DCVoltage(Component):
    def __init__(self,node1,node2,voltage=0):
        super().__init__(node1,node2)
        self.highNode = node1
        self.voltage = voltage
    def __hash__(self):
        return hash((tuple(self.nodeSet),self.voltage))
    def __eq__(self,other):
        return isinstance(other,DCVoltage) and hash(self) == hash(other)
    def __repr__(self):
        return f'DCVoltage @ {self.nodeSet}'

class ParallelCombo(Component):
    def __init__(self,node1,node2,parallelSet):
        super().__init__(node1,node2)
        self.parallelSet = parallelSet
    def __hash__(self):
        return hash(tuple(self.parallelSet))
    def __eq__(self,other):
        return isinstance(other,ParallelCombo) and hash(self) == hash(other)
    def __repr__(self):
        return f'Parallel Combo @ {self.nodeSet} with components {self.parallelSet}'
        #return f'Parallel Combo @ {self.nodeSet}'
    

class SeriesCombo(Component):
    def __init__(self,node1,node2,seriesSet):
        super().__init__(node1,node2)
        self.seriesSet = seriesSet
    def __hash__(self):
        return hash(tuple(self.seriesSet))
    def __eq__(self,other):
        return isinstance(other,SeriesCombo) and hash(self) == hash(other)
    def __repr__(self):
        return f'Series combo @ {self.nodeSet} with components {self.seriesSet}'
        #return f'Series Combo @ {self.nodeSet}'
        
class Circuit(object):
    def __init__(self):
        self.nodes = dict()
        self.comps = set()
        self.reducedNodes = dict()
        self.reducedComps = set()

    def addComp(self,comp):
        self.comps.add(comp)
        node1, node2 = tuple(comp.nodeSet)
        if(node1 in self.nodes):
            self.nodes[node1].add(comp)
        else:
            self.nodes[node1] = {comp}
        if(node2 in self.nodes):
            self.nodes[node2].add(comp)
        else:
            self.nodes[node2] = {comp}
        self.reducedNodes = copy.deepcopy(self.nodes)
        self.reducedComps = copy.deepcopy(self.comps)

    def addComboComp(self,comp):
        self.reducedComps.add(comp)
        node1, node2 = tuple(comp.nodeSet)
        if(node1 in self.reducedNodes):
            self.reducedNodes[node1].add(comp)
        else:
            self.reducedNodes[node1] = {comp}
        if(node2 in self.reducedNodes):
            self.reducedNodes[node2].add(comp)
        else:
            self.reducedNodes[node2] = {comp}

    def removeComboComp(self,comp):
        #bugs with hash function, this fixes it
        reducedCopy = copy.deepcopy(self.reducedComps)
        self.reducedComps = reducedCopy
        nodeCopy = copy.deepcopy(self.reducedNodes)
        self.reducedNodes = nodeCopy

        self.reducedComps.remove(comp)
        node1, node2 = tuple(comp.nodeSet)
        self.reducedNodes[node1].remove(comp)
        self.reducedNodes[node2].remove(comp)
        if(self.reducedNodes[node1] == set()):
            del self.reducedNodes[node1]
        if(self.reducedNodes[node2] == set()):
            del self.reducedNodes[node2]

    def getSeries(self):
        branchList = []
        for node in self.reducedNodes:
            compList = copy.deepcopy(self.reducedNodes[node])
            if(len(compList) == 2):
                added = False
                for branch in branchList:
                    for comp in compList:
                        if comp in branch:
                            branch = branch|compList
                            added = True
                if not added:
                    branchList.append(compList)
        return branchList

    def getBranchStartEnd(self,branch):
        nodeSet = set()
        for comp in branch:
            node1,node2 = tuple(comp.nodeSet)
            if(node1 in nodeSet):
                nodeSet.remove(node1)
            else:
                nodeSet.add(node1)
            if(node2 in nodeSet):
                nodeSet.remove(node2)
            else:
                nodeSet.add(node2)
        return nodeSet
    
    def reduceFromBranchList(self,branchList):
        for branch in branchList:
            for comp in branch:
                self.removeComboComp(comp)
            nodeSet = self.getBranchStartEnd(branch)
            node1,node2 = tuple(nodeSet)
            self.addComboComp(SeriesCombo(node1,node2,branch))

    def getParallel(self):
        parallelList = []
        reducedComps = copy.deepcopy(self.reducedComps)
        for comp in reducedComps:
            parallelSet = set()
            for comp2 in reducedComps:
                if comp2.nodeSet == comp.nodeSet:
                    parallelSet.add(comp2)
            if(len(parallelSet)>1 and parallelSet not in parallelList):
                parallelList.append(parallelSet)
        return parallelList

    def reduceFromParallelList(self,parallelList):        
        for parallelSet in parallelList:
            nodeSet = set()
            for comp in parallelSet:
                nodeSet = comp.nodeSet
                self.removeComboComp(comp)
            node1,node2 = tuple(nodeSet)
            self.addComboComp(ParallelCombo(node1,node2,parallelSet))
    
    def reduceCircuit(self):
        branchList = [1]
        parallel = [1]

        while(branchList != [] or parallel != []):
            branchList = self.getSeries()
            self.reduceFromBranchList(branchList)
            parallel = self.getParallel()
            self.reduceFromParallelList(parallel)
            
def testBranches():
    node1 = Node(0,0)
    node2 = Node(0,1)
    node3 = Node(1,1)
    node4 = Node(2,0)
    node5 = Node(2,2)
    node6 = Node(3,1)
    node7 = Node(4,0)
    #node8 = Node(10,10)
    #node9 = Node(7,7)
    
    batt = DCVoltage(node1,node7)
    res1 = Resistor(node1,node3)
    res2 = Resistor(node3,node4)
    res3 = Resistor(node4,node7)
    res4 = Resistor(node3,node5)
    res5 = Resistor(node5,node7)
    res6 = Resistor(node5,node6)
    res7 = Resistor(node6,node7)
    #res8 = Resistor(node8,node9)
    
    circ = Circuit()
    circ.addComp(batt)
    circ.addComp(res1)
    circ.addComp(res2)
    circ.addComp(res3)
    circ.addComp(res4)
    circ.addComp(res5)
    circ.addComp(res6)
    circ.addComp(res7)
    circ.addComp(res8)

    

    '''
    branchList = circ.getSeries()
    circ.reduceFromBranchList(branchList)

    
    parallel = circ.getParallel()
    circ.reduceFromParallelList(parallel)

        
    branchList = circ.getSeries()
    circ.reduceFromBranchList(branchList)
        
    parallel = circ.getParallel()
    circ.reduceFromParallelList(parallel)
    '''

    circ.reduceCircuit()

    
    for comp in circ.reducedComps:
        print(comp)


    '''
    for node in circ.reducedNodes:
        print(node,circ.reducedNodes[node])
        print()
        print()
    '''
    
    

    
    

testBranches()
        

